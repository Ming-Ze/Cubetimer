﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CubeTimer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            scramble.Text = sc.Generate();
            scramble.Location = new Point((Width - scramble.Width) / 2, 12);
            time.Location = new Point((Width - time.Width) / 2, (Height - time.Height) / 2 - 75);   
            //有關location的東西純粹是為了調整成績的位置
        }
        
        bool timing = false;
        private DateTime startTime;
        Scramble sc = new Scramble();

        private void Timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan timeElapsed = DateTime.Now - startTime;
            time.Text = timeElapsed.TotalSeconds.ToString("0.00");
            if(timeElapsed.Seconds >= 10)
            {
                time.Location = new Point((Width - time.Width) / 2, (Height - time.Height) / 2 - 75);
            }
            if(timeElapsed.Minutes >= 1)
            {
                time.Text = timeElapsed.Minutes.ToString() + ":" + timeElapsed.Seconds.ToString("00") + "." + (timeElapsed.Milliseconds / 10).ToString("00");
                time.Location = new Point((Width - time.Width) / 2, (Height - time.Height) / 2 - 75);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (timing)
                return;
            time.Text = "0.00";
            time.ForeColor = Color.Green;
            time.Location = new Point((Width - time.Width) / 2, (Height - time.Height) / 2 - 75);
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            time.ForeColor = Color.Black;
            if (!timing)
            {
                startTime = DateTime.Now;
                timer1.Start();
                timing = true;
            }
            else
            {
                timer1.Stop();
                timing = false;
                scramble.Text = sc.Generate();
                scramble.Location = new Point((Width - scramble.Width) / 2, 12);
            }        
        }

        private void B_guide_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            scramble.Focus();
        }

        private void B_change_Click(object sender, EventArgs e)
        {
            scramble.Text = sc.Generate();
            scramble.Location = new Point((Width - scramble.Width) / 2, 12);
            scramble.Focus();
        }
    }
}
