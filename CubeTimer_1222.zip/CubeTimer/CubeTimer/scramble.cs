﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CubeTimer
{
    class Scramble
    {
        public String Generate()
        {
            String str = "";
            int pre_n1 = 6;
            Random rnd = new Random();

            for(int i=0; i<20; i++)
            {               
                int n1 = rnd.Next(6);
                int n2 = rnd.Next(10);

                if(n1 == pre_n1)
                {
                    i--;
                    continue;
                }
                else if(n1 == 0)              
                    str += "R";                
                else if(n1 == 1)
                    str += "L";
                else if (n1 == 2)
                    str += "U";
                else if (n1 == 3)
                    str += "D";
                else if (n1 == 4)
                    str += "F";
                else
                    str += "B";

                if (n2 <= 2)
                    str += "' ";
                else if(n2 <= 6)
                    str += " ";
                else
                    str += "2 ";

                pre_n1 = n1;
            }

            return str;
        }
    }
}
