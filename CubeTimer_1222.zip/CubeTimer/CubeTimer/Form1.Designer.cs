﻿namespace CubeTimer
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.time = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.scramble = new System.Windows.Forms.Label();
            this.B_guide = new System.Windows.Forms.Button();
            this.B_change = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.Font = new System.Drawing.Font("Segoe UI", 96F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.Location = new System.Drawing.Point(342, 215);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(461, 254);
            this.time.TabIndex = 0;
            this.time.Text = "0.00";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // scramble
            // 
            this.scramble.AutoSize = true;
            this.scramble.Font = new System.Drawing.Font("Segoe UI", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scramble.Location = new System.Drawing.Point(12, 9);
            this.scramble.Name = "scramble";
            this.scramble.Size = new System.Drawing.Size(0, 74);
            this.scramble.TabIndex = 1;
            // 
            // B_guide
            // 
            this.B_guide.BackColor = System.Drawing.SystemColors.ControlDark;
            this.B_guide.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_guide.Location = new System.Drawing.Point(1116, 9);
            this.B_guide.Name = "B_guide";
            this.B_guide.Size = new System.Drawing.Size(50, 50);
            this.B_guide.TabIndex = 2;
            this.B_guide.TabStop = false;
            this.B_guide.Text = "？";
            this.B_guide.UseVisualStyleBackColor = false;
            this.B_guide.Click += new System.EventHandler(this.B_guide_Click);
            // 
            // B_change
            // 
            this.B_change.BackColor = System.Drawing.SystemColors.ControlDark;
            this.B_change.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B_change.Location = new System.Drawing.Point(1060, 9);
            this.B_change.Name = "B_change";
            this.B_change.Size = new System.Drawing.Size(50, 50);
            this.B_change.TabIndex = 3;
            this.B_change.TabStop = false;
            this.B_change.Text = "new";
            this.B_change.UseVisualStyleBackColor = false;
            this.B_change.Click += new System.EventHandler(this.B_change_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 744);
            this.Controls.Add(this.B_change);
            this.Controls.Add(this.B_guide);
            this.Controls.Add(this.scramble);
            this.Controls.Add(this.time);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CubeTimer";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label scramble;
        private System.Windows.Forms.Button B_guide;
        private System.Windows.Forms.Button B_change;
    }
}

